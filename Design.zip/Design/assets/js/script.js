const trailCircle = document.querySelector(".trail-circle");
let mouseX = 0,
  mouseY = 0;
let posX = 0,
  posY = 0;
const delay = 0.1;

document.addEventListener("mousemove", (e) => {
  mouseX = e.pageX;
  mouseY = e.pageY;
});

function animateTrail() {
  posX += (mouseX - posX) * delay;
  posY += (mouseY - posY) * delay;
  trailCircle.style.transform = `translate3d(${posX}px, ${posY}px, 0)`;
  requestAnimationFrame(animateTrail);
}
animateTrail();

addEventListener("DOMContentLoaded", (event) => {
  function updateGreeting() {
    const now = new Date();
    const hour = now.getHours();
    let greeting;
    if (hour < 12) {
      greeting = "Good Morning!";
    } else if (hour < 18) {
      greeting = "Good Afternoon!";
    } else {
      greeting = "Good Evening!";
    }
    // document.title = greeting;
    const headerLogo = document.querySelector('.header__logo');
    headerLogo.innerHTML = greeting;
  }
  updateGreeting();
  setInterval(updateGreeting, 3600000);
});
